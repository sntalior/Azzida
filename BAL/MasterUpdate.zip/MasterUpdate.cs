﻿using DAL;
using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Mail;
using System.Net;

namespace BAL
{
    public class MasterUpdate : BusinessBase
    { 
         public UserMaster Register(int Id, int RoleId, string FirstName, string LastName, string UserPassword, 
             string UserEmail, string Skills, string DeviceId, string DeviceType,string GoogleEmail,string FacebookEmail)
        {
            UserMaster um = new UserMaster();
            if (Id > 0)
            {
                um = (from a in DB.UserMasters where a.Id == Id select a).FirstOrDefault();
                um.RoleId = RoleId;
                um.FirstName = FirstName;
                um.LastName = LastName;
                um.UserPassword = UserPassword;
                um.UserEmail = UserEmail;
                um.Skills = Skills;
                um.DeviceId = DeviceId;
                um.DeviceType = DeviceType;
                um.GoogleEmail = GoogleEmail;
                um.FaceBookEmail = FacebookEmail;
                um.ModifyDate = DateTime.Now;
            }
            else
            {
                um.RoleId = RoleId;
                um.FirstName = FirstName;
                um.LastName = LastName;
                um.UserPassword = UserPassword;
                um.UserEmail = UserEmail;
                um.Skills = Skills;
                um.DeviceId = DeviceId;
                um.DeviceType = DeviceType;
                um.GoogleEmail = GoogleEmail;
                um.FaceBookEmail = FacebookEmail;
                um.CreatedDate = DateTime.Now;
                DB.UserMasters.InsertOnSubmit(um);
            }
            DB.SubmitChanges();
            return um;
        }
        public Tip Tipp(int Id,int UserId,int JobId,string TippingAmount,string TotalAmount)
        {
            Tip t = new Tip();
            if (Id > 0)
            {
                t = (from a in DB.Tips where a.Id == Id select a).FirstOrDefault();
                t.UserId = UserId;
                t.JobId = JobId;
                t.TippingAmount =Convert.ToDecimal (TippingAmount);
                t.TotalAmount = Convert.ToDecimal(TotalAmount);
                t.ModifyDate = DateTime.Now;
            }
            else
            {
                t.UserId = UserId;
                t.JobId = JobId;
                t.TippingAmount = Convert.ToDecimal(TippingAmount);
                t.TotalAmount = Convert.ToDecimal(TotalAmount);
                t.CreatedDate = DateTime.Now;
                DB.Tips.InsertOnSubmit(t);
            }
            DB.SubmitChanges();
            return t;
        }
        public Rate RatePost(int Id,int UserId,int JobId,int Rate)
        {
            Rate um = new Rate();
            if (Id > 0)
            {
                um = (from a in DB.Rates where a.Id == Id select a).FirstOrDefault();
                um.UserId = UserId;
                um.JobId = JobId;
                um.Rate1 = Rate;
                um.ModifyDate = DateTime.Now;
            }
            else
            {
                um.UserId = UserId;
                um.JobId = JobId;
                um.Rate1 = Rate;
                um.CreateDate = DateTime.Now;
                DB.Rates.InsertOnSubmit(um);
            }
            DB.SubmitChanges();
            return um;
        }
        public UserMaster UserActiveDeactive(int Id)
        {
            UserMaster um = new UserMaster();
            
           um = (from a in DB.UserMasters where a.Id == Id select a).FirstOrDefault();
            if (um.IsActive.ToString() == "true")
            {
                um.IsActive = false;
            }
            else
            {
                um.IsActive = true;
            }
               

          
            DB.SubmitChanges();
            return um;
        }
        public UserMaster UserLogin(string UserEmail, string UserPassword)
        {
            var data = (from a in DB.UserMasters where a.UserEmail == UserEmail && a.UserPassword == UserPassword select a).FirstOrDefault();
            return data;
        }
        public UserMaster LoginAdmin(string UserEmail, string UserPassword)
        {
            var data = (from a in DB.UserMasters where a.UserEmail == UserEmail && a.UserPassword == UserPassword select a).FirstOrDefault();
            return data;
        }

       public UserMaster IsEmailExist(string UserEmail)
        {
            return (from a in DB.UserMasters where a.UserEmail == UserEmail select a).FirstOrDefault();
        }

        public List<UserMaster> GetUserList()
        {
            var data = (from a in DB.UserMasters select a).ToList();
            return data;
        }

        public UserMaster GetUserById(int Id)
        {
            var data = (from a in DB.UserMasters where a.Id == Id select a).FirstOrDefault();
            return data;
        }

        public void DeleteUserById(int Id)
        {
            var data = (from a in DB.UserMasters where a.Id == Id select a).FirstOrDefault();
            DB.UserMasters.DeleteOnSubmit(data);
            DB.SubmitChanges();
        }
        public List<Job> GetRecentActivity (int UserId)
        {
            var data = (from a in DB.Jobs where a.UserId==UserId select a).ToList();
            return data;
        }

        public List<Job> GetJob()
        {
            var data = (from a in DB.Jobs select a).ToList();
            return data;
        }

        public List<DisputeResolution> GetDisputeResolution()
        {
            var data = (from a in DB.DisputeResolutions select a).ToList();
            return data;
        }


        public Job CreateJob(int Id,int UserId, string JobTitle, string HowLong, string Amount,
            string JobCategory, string Location,string FromDate, string JobDescription, string Latitude,
            string Longitude,string CompletedDate, string JobPicture)
        {
            Job j = new Job();
            if (Id > 0)
            {
                j = (from a in DB.Jobs where a.Id == Id select a).FirstOrDefault();
                j.UserId = UserId;
                j.JobTitle = JobTitle;
                j.HowLong = HowLong;
                j.Amount = Convert.ToDecimal(Amount);
                j.JobCategory = JobCategory;
                j.Location = Location;
                j.FromDate = FromDate;
                j.JobDescription = JobDescription;
                j.Latitude = Latitude;
                j.Longitude = Longitude;
                j.CompletedDate = CompletedDate;
                j.JobPicture = JobPicture;
                j.ModifyDate = DateTime.Now;

            }
            else
            {
                j.UserId = UserId;
                j.JobTitle = JobTitle;
                j.HowLong = HowLong;
                j.Amount = Convert.ToDecimal(Amount);
                j.JobCategory = JobCategory;
                j.Location = Location;
                j.FromDate = FromDate;
                j.JobDescription = JobDescription;
                j.Latitude = Latitude;
                j.Longitude = Longitude;
                j.CompletedDate = CompletedDate;
                j.JobPicture = JobPicture;
                j.CreatedDate = DateTime.Now;
                DB.Jobs.InsertOnSubmit(j);

            }
            DB.SubmitChanges();
            return j;
        }

        public Job JobComplete(int Id, string IsComplete)
        {
            var data = (from a in DB.Jobs where a.Id == Id select a).FirstOrDefault();
            if (data != null)
            {
                data.IsComplete = true;
                DB.SubmitChanges();
            }
            return data;
        }
        public JobCategory CreateJobCategory(int Id, string CategoryName)
        {
            JobCategory jc = new JobCategory();
            if (Id > 0)
            {
                jc = (from a in DB.JobCategories where a.Id == Id select a).FirstOrDefault();
                jc.CategoryName = CategoryName;

            }
            else
            {
                jc.CategoryName = CategoryName;
                DB.JobCategories.InsertOnSubmit(jc);
            }
            DB.SubmitChanges();
            return jc;
        }

        public List<JobCategory> GetJobCategory()
        {
            var data = (from a in DB.JobCategories select a).ToList();
            return data;
        }

        public JobCategory GetJobCategoryById(int Id)
        {
            var data = (from a in DB.JobCategories where a.Id == Id select a).FirstOrDefault();
            return data;
        }

        public void DeleteCategoryById(int Id)
        {
            var data = (from a in DB.JobCategories where a.Id == Id select a).FirstOrDefault();
            DB.JobCategories.DeleteOnSubmit(data);
            DB.SubmitChanges();
        }


        public DisputeResolution SaveDispute(int Id, int UserId, int JobId,
            string DisputeReason, string PostAssociate, string ContactWay,
            string Description, string Attachment)
        {
            DisputeResolution dr = new DisputeResolution();
            if (Id > 0)
            {
                dr = (from a in DB.DisputeResolutions where a.Id == Id select a).FirstOrDefault();
                dr.UserId = UserId;
                dr.JobId = JobId;
                dr.DisputeReason = DisputeReason;
                dr.PostAssociate = PostAssociate;
                dr.ContactWay = ContactWay;
                dr.Description = Description;
                if (Attachment != "")
                {
                    dr.Attachment = Attachment;
                }
               
                dr.ModifyDate = DateTime.Now;
            }
            else
            {
                dr.UserId = UserId;
                dr.JobId = JobId;
                dr.DisputeReason = DisputeReason;
                dr.PostAssociate = PostAssociate;
                dr.ContactWay = ContactWay;
                dr.Description = Description;
                dr.Attachment = Attachment;
                dr.CreatedDate = DateTime.Now;
                DB.DisputeResolutions.InsertOnSubmit(dr);
            }
            DB.SubmitChanges();
            return dr;
        }

        public List<RoleMaster> GetRoles()
        {
            var data = (from a in DB.RoleMasters select a).ToList();
            return data;
        }
    }
}